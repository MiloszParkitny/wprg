<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login-register.php");
    exit();
}

require 'zamowienie-skladanie.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = new mysqli("localhost", "my_user", "my_password", "wprg-projekt");

    if ($db->connect_error) {
        die("Połączenie nieudane: " . $db->connect_error);
    }

    $user_id = $_SESSION['user_id'];
    $products = $_SESSION['koszyk'];
    $shipping_info = $_SESSION['shipping_address'];
    $payment_method = $_SESSION['payment_method'];
    $contact_info = $_SESSION['contact_info'];
    $discount = isset($_SESSION['discount']) ? $_SESSION['discount'] : 0;

    $order = new Order($db);
    $order_id = $order->createOrder($user_id, $shipping_info, $payment_method, $contact_info, $products, $discount);

    sendConfirmationEmail($contact_info['email'], $order_id, $products, $shipping_info, $contact_info, $payment_method, $discount);

    unset($_SESSION['koszyk']);
    unset($_SESSION['discount']);
    unset($_SESSION['shipping_address']);
    unset($_SESSION['payment_method']);
    unset($_SESSION['contact_info']);

    header("Location: order_confirmation.php?order_id=$order_id");
    exit();
}

function sendConfirmationEmail($to, $order_id, $products, $shipping_info, $contact_info, $payment_method, $discount) {
    $subject = "Potwierdzenie zamówienia nr $order_id";
    $headers = "From: sklep@example.com\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

    $message = "<h1>Dziękujemy za zamówienie!</h1>";
    $message .= "<p>Twoje zamówienie nr <strong>$order_id</strong> zostało przyjęte.</p>";
    $message .= "<h2>Szczegóły zamówienia:</h2>";
    $message .= "<ul>";

    foreach ($products as $product) {
        $message .= "<li>" . $product['marka'] . " " . $product['model'] . " - Rozmiar: " . $product['rozmiar'] . " - Cena: " . $product['cena'] . " PLN</li>";
    }

    $message .= "</ul>";
    $message .= "<p>Łączna wartość zamówienia (z uwzględnieniem rabatu): <strong>" . calculateTotal($products, $discount) . " PLN</strong></p>";
    $message .= "<h2>Adres wysyłki:</h2>";
    $message .= "<p>" . $shipping_info['name'] . "<br>" . $shipping_info['address'] . "<br>" . $shipping_info['city'] . ", " . $shipping_info['zip'] . "<br>" . $shipping_info['country'] . "</p>";
    $message .= "<h2>Dane kontaktowe:</h2>";
    $message .= "<p>Email: " . $contact_info['email'] . "<br>Telefon: " . $contact_info['phone'] . "</p>";
    $message .= "<h2>Metoda płatności:</h2>";
    $message .= "<p>" . $payment_method . "</p>";

    mail($to, $subject, $message, $headers);
}

function calculateTotal($products, $discount) {
    $total = 0;
    foreach ($products as $product) {
        $total += $product['cena'];
    }
    $total -= $total * $discount;
    return number_format($total, 2);
}
?>

