<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unikatowe Ubrania - Produkty</title>
    <link rel="stylesheet" href="main-styles.css">
</head>
<body>
<header>
    <div class="container">
        <div class="left-logo">
            <a href="index.php"><img src="icon/icon-shop-logo.png" alt="logo sklepu"></a>
        </div>
        <nav>
            <ul>
                <li><a href="kategoria-ubrania.php">Ubrania</a></li>
                <li><a href="kategoria-buty.php">Buty</a></li>
                <li><a href="kategoria-akcesoria.php">Akcesoria</a></li>
            </ul>
        </nav>
        <div class="search">
            <form action="search.php" method="get">
                <input type="text" name="query" placeholder="Szukaj...">
                <button type="submit">Szukaj</button>
            </form>
        </div>
        <div class="right-section">
            <div class="cart">
                <a href="koszyk.php">Koszyk (<?php echo count($_SESSION['koszyk'] ?? []); ?>)</a>
            </div>
            <?php if (isset($_SESSION['user_id'])): ?>
                <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                    <div class="admin">
                        <a href="admin.php">Admin Panel</a>
                    </div>
                <?php else: ?>
                    <div class="account">
                        <a href="moje-konto.php">Moje Konto</a>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            <div class="right-logo">
                <?php
                if (isset($_SESSION['user_id'])) {
                    echo '<form action="login-register-system.php" method="post">';
                    echo '<input type="hidden" name="action" value="logout">';
                    echo '<button type="submit" class="logout-button">Wyloguj się</button>';
                    echo '</form>';
                } else {
                    echo '<a href="login-register.php"><img src="icon/icon-login-register.png" alt="login icon"></a>';
                }
                ?>
            </div>
        </div>
    </div>
</header>
<main class="container">