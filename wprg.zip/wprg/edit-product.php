<?php
include 'header.php';
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

$id = $_GET['id'];
$db = new mysqli("localhost", "my_user", "my_password", "wprg-projekt");

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $marka = $_POST['marka'];
    $model = $_POST['model'];
    $opis = $_POST['opis'];
    $cena = $_POST['cena'];
    $kategoria = $_POST['kategoria'];
    $obrazek = $_POST['obrazek'];

    $stmt = $db->prepare("UPDATE produkty SET marka = ?, model = ?, opis = ?, cena = ?, kategoria = ?, obrazek = ? WHERE id = ?");
    $stmt->bind_param("ssssssi", $marka, $model, $opis, $cena, $kategoria, $obrazek, $id);
    $stmt->execute();
    $stmt->close();

    header("Location: admin.php?section=products");
    exit();
}

$stmt = $db->prepare("SELECT * FROM produkty WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
$stmt->close();
$db->close();
?>
<h2 class="h2-moje-konto">Edytuj Produkt</h2>
<form action="edit-product.php?id=<?php echo $id; ?>" method="post" class="edycja-form">
    <label for="marka" class="edycja-label">Marka:</label>
    <input type="text" id="marka" name="marka" value="<?php echo $product['marka']; ?>" required class="edycja-input">

    <label for="model" class="edycja-label">Model:</label>
    <input type="text" id="model" name="model" value="<?php echo $product['model']; ?>" required class="edycja-input">

    <label for="opis" class="edycja-label">Opis:</label>
    <textarea id="opis" name="opis" required class="edycja-textarea"><?php echo $product['opis']; ?></textarea>

    <label for="cena" class="edycja-label">Cena:</label>
    <input type="number" id="cena" name="cena" step="0.01" value="<?php echo $product['cena']; ?>" required class="edycja-input">

    <label for="kategoria" class="edycja-label">Kategoria:</label>
    <input type="text" id="kategoria" name="kategoria" value="<?php echo $product['kategoria']; ?>" required class="edycja-input">

    <label for="obrazek" class="edycja-label">Obrazek:</label>
    <input type="text" id="obrazek" name="obrazek" value="<?php echo $product['obrazek']; ?>" required class="edycja-input">

    <button type="submit" class="edycja-button">Zapisz zmiany</button>
</form>
<?php include 'footer.php'; ?>
