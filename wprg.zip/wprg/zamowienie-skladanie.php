<?php
include 'header.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login-register.php");
    exit();
}

class Order {
    private $db;

    public function __construct() {
        $this->db = new mysqli("localhost", "my_user", "my_password", "wprg-projekt");

        if ($this->db->connect_error) {
            die("Połączenie nieudane: " . $this->db->connect_error);
        }
    }

    public function processOrder($userId, $products, $shippingInfo, $paymentMethod, $contactInfo, $discount = 0) {
        $total = 0;

        foreach ($products as $product) {
            $stmt = $this->db->prepare("SELECT cena FROM produkty WHERE id = ?");
            $stmt->bind_param("i", $product['id']);
            $stmt->execute();
            $stmt->bind_result($cena);
            $stmt->fetch();
            $stmt->close();

            if (!$cena) {
                die("Nieprawidłowe ID produktu: " . $product['id']);
            }

            $total += $cena;
        }

        $total -= $total * $discount;

        $stmt = $this->db->prepare("INSERT INTO zamowienia (user_id, total, shipping_name, shipping_address, shipping_city, shipping_zip, shipping_country, payment_method, contact_email, contact_phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("idssssssss", $userId, $total, $shippingInfo['name'], $shippingInfo['address'], $shippingInfo['city'], $shippingInfo['zip'], $shippingInfo['country'], $paymentMethod, $contactInfo['email'], $contactInfo['phone']);
        $stmt->execute();
        $orderId = $stmt->insert_id;
        $stmt->close();

        foreach ($products as $product) {
            $stmt = $this->db->prepare("INSERT INTO zamowienia_produkty (zamowienie_id, produkt_id, rozmiar) VALUES (?, ?, ?)");
            $stmt->bind_param("iis", $orderId, $product['id'], $product['rozmiar']);
            $stmt->execute();
            $stmt->close();
        }

        return $orderId;
    }

    public function __destruct() {
        $this->db->close();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['shipping_address'] = [
        'name' => $_POST['name'],
        'address' => $_POST['address'],
        'city' => $_POST['city'],
        'zip' => $_POST['zip'],
        'country' => $_POST['country']
    ];
    $_SESSION['payment_method'] = $_POST['payment_method'];
    $_SESSION['contact_info'] = [
        'email' => $_POST['email'],
        'phone' => $_POST['phone']
    ];

    $order = new Order();
    $userId = $_SESSION['user_id'];
    $products = $_SESSION['koszyk'];
    $shippingInfo = $_SESSION['shipping_address'];
    $paymentMethod = $_SESSION['payment_method'];
    $contactInfo = $_SESSION['contact_info'];
    $discount = $_SESSION['discount'] ?? 0;

    $orderId = $order->processOrder($userId, $products, $shippingInfo, $paymentMethod, $contactInfo, $discount);

    unset($_SESSION['koszyk']);
    unset($_SESSION['shipping_address']);
    unset($_SESSION['payment_method']);
    unset($_SESSION['contact_info']);
    unset($_SESSION['discount']);

    header("Location: order_confirmation.php?order_id=" . $orderId);
    exit();
}

$pageTitle = "Składanie zamówienia";

?>
<h2 class="h2-moje-konto">Składanie zamówienia</h2>
<form action="zamowienie-skladanie.php" method="post" class="zamowienie-form" onsubmit="return validateForm()">
    <h3>Adres wysyłki</h3>
    <label for="name">Imię i nazwisko:</label>
    <input type="text" id="name" name="name" required pattern="[A-Za-zÀ-ž\s]+" title="Imię i nazwisko mogą zawierać tylko litery i spacje">
    <label for="address">Adres:</label>
    <input type="text" id="address" name="address" required>
    <label for="city">Miasto:</label>
    <input type="text" id="city" name="city" required pattern="[A-Za-zÀ-ž\s]+" title="Miasto może zawierać tylko litery i spacje">
    <label for="zip">Kod pocztowy:</label>
    <input type="text" id="zip" name="zip" required pattern="\d{2}-\d{3}" title="Kod pocztowy w formacie 00-000">
    <label for="country">Kraj:</label>
    <input type="text" id="country" name="country" required pattern="[A-Za-zÀ-ž\s]+" title="Kraj może zawierać tylko litery i spacje">

    <h3>Metoda płatności</h3>
    <label for="payment_method">Metoda płatności:</label>
    <select id="payment_method" name="payment_method" required>
        <option value="karta">Karta kredytowa/debetowa</option>
        <option value="paypal">PayPal</option>
        <option value="przelew">Przelew bankowy</option>
    </select>

    <h3>Dane kontaktowe</h3>
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required>
    <label for="phone">Telefon:</label>
    <input type="text" id="phone" name="phone" required pattern="\d{9}" title="Numer telefonu powinien składać się z 9 cyfr">

    <button type="submit" class="button">Zamawiam</button>
</form>

<script>
    function validateForm() {
        var name = document.getElementById("name").value;
        var address = document.getElementById("address").value;
        var city = document.getElementById("city").value;
        var zip = document.getElementById("zip").value;
        var country = document.getElementById("country").value;
        var email = document.getElementById("email").value;
        var phone = document.getElementById("phone").value;
        var paymentMethod = document.getElementById("payment_method").value;

        if (!/^[A-Za-zÀ-ž\s]+$/.test(name)) {
            alert("Imię i nazwisko mogą zawierać tylko litery i spacje");
            return false;
        }
        if (!/^[A-Za-zÀ-ž\s]+$/.test(city)) {
            alert("Miasto może zawierać tylko litery i spacje");
            return false;
        }
        if (!/^\d{2}-\d{3}$/.test(zip)) {
            alert("Kod pocztowy w formacie 00-000");
            return false;
        }
        if (!/^[A-Za-zÀ-ž\s]+$/.test(country)) {
            alert("Kraj może zawierać tylko litery i spacje");
            return false;
        }
        if (!/^\d{9}$/.test(phone)) {
            alert("Numer telefonu powinien składać się z 9 cyfr");
            return false;
        }

        return true;
    }
</script>
<?php include 'footer.php'; ?>

