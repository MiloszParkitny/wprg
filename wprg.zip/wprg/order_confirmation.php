<?php
include 'header.php';

$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
$db = new mysqli("localhost", "my_user", "my_password", "wprg-projekt");

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$stmt = $db->prepare("SELECT * FROM zamowienia WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

$stmt = $db->prepare("SELECT * FROM zamowienia_produkty zp JOIN produkty p ON zp.produkt_id = p.id WHERE zamowienie_id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$db->close();
?>
<div class="potwierdzenie-container">
    <h2 class="potwierdzenie-title">Potwierdzenie Zamówienia</h2>
    <div class="potwierdzenie-order-details">
        <p><span class="potwierdzenie-label">Numer zamówienia:</span> <?php echo $order_id; ?></p>
        <p><span class="potwierdzenie-label">Łączna wartość:</span> <?php echo number_format($order['total'], 2); ?> PLN</p>
        <p><span class="potwierdzenie-label">Data zamówienia:</span> <?php echo $order['order_date']; ?></p>
    </div>
    <h3 class="potwierdzenie-subtitle">Adres wysyłki</h3>
    <div class="potwierdzenie-shipping-address">
        <p><?php echo $order['shipping_name']; ?></p>
        <p><?php echo $order['shipping_address']; ?></p>
        <p><?php echo $order['shipping_city']; ?></p>
        <p><?php echo $order['shipping_zip']; ?></p>
        <p><?php echo $order['shipping_country']; ?></p>
    </div>
    <h3 class="potwierdzenie-subtitle">Metoda płatności</h3>
    <p class="potwierdzenie-payment-method"><?php echo $order['payment_method']; ?></p>
    <h3 class="potwierdzenie-subtitle">Kontakt</h3>
    <p class="potwierdzenie-contact-info">Email: <?php echo $order['contact_email']; ?></p>
    <p class="potwierdzenie-contact-info">Telefon: <?php echo $order['contact_phone']; ?></p>
    <h3 class="potwierdzenie-subtitle">Produkty</h3>
    <ul class="potwierdzenie-product-list">
        <?php foreach ($products as $product): ?>
            <li class="potwierdzenie-product-item">
                <img src="<?php echo $product['obrazek']; ?>" alt="<?php echo $product['model']; ?>" class="potwierdzenie-product-image">
                <div class="potwierdzenie-product-details">
                    <p><?php echo $product['marka'] . " " . $product['model'] . " (Rozmiar: " . $product['rozmiar'] . ")"; ?></p>
                </div>
            </li>
        <?php endforeach; ?>
    </ul>
</div>
<?php include 'footer.php'; ?>
