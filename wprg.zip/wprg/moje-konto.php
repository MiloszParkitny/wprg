<?php
include 'header.php';

$db = new mysqli("localhost", "my_user", "my_password", "wprg-projekt");

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login-register.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    if (!empty($password)) {
        $passwordHash = password_hash($password, PASSWORD_ARGON2I);
        $q = $db->prepare("UPDATE user SET imie = ?, nazwisko = ?, email = ?, haslo = ? WHERE id = ?");
        $q->bind_param("ssssi", $firstname, $lastname, $email, $passwordHash, $user_id);
    } else {
        $q = $db->prepare("UPDATE user SET imie = ?, nazwisko = ?, email = ? WHERE id = ?");
        $q->bind_param("sssi", $firstname, $lastname, $email, $user_id);
    }

    if ($q->execute()) {
        $_SESSION['user_email'] = $email;
        $_SESSION['success_message'] = "Dane konta zostały zaktualizowane.";
    } else {
        $_SESSION['error_message'] = "Wystąpił błąd podczas aktualizacji danych.";
    }

    $q->close();
}

$q = $db->prepare("SELECT imie, nazwisko, email FROM user WHERE id = ? LIMIT 1");
$q->bind_param("i", $user_id);
$q->execute();
$result = $q->get_result();
$user = $result->fetch_assoc();
$q->close();

$q = $db->prepare("SELECT id, total, order_date FROM zamowienia WHERE user_id = ? ORDER BY order_date DESC");
$q->bind_param("i", $user_id);
$q->execute();
$result = $q->get_result();
$orders = $result->fetch_all(MYSQLI_ASSOC);
$q->close();

$db->close();
?>
<h2 class="h2-moje-konto">Moje Konto</h2>
<?php
if (isset($_SESSION['error_message'])) {
    echo "<p class='error'>" . $_SESSION['error_message'] . "</p>";
    unset($_SESSION['error_message']);
}

if (isset($_SESSION['success_message'])) {
    echo "<p class='success'>" . $_SESSION['success_message'] . "</p>";
    unset($_SESSION['success_message']);
}
?>
<div class="account-page">
    <div class="section-box">
        <form action="moje-konto.php" method="post" class="account-form">
            <label for="firstname">Imię:</label>
            <input type="text" id="firstname" name="firstname" value="<?php echo htmlspecialchars($user['imie']); ?>" required>

            <label for="lastname">Nazwisko:</label>
            <input type="text" id="lastname" name="lastname" value="<?php echo htmlspecialchars($user['nazwisko']); ?>" required>

            <label for="email">Adres Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>

            <label for="password">Hasło (pozostaw puste, aby nie zmieniać):</label>
            <input type="password" id="password" name="password">

            <button type="submit">Zaktualizuj dane</button>
        </form>
    </div>

    <div class="section-box">
        <h3>Historia zamówień</h3>
        <?php if (empty($orders)): ?>
            <p>Brak zamówień.</p>
        <?php else: ?>
            <ul class="order-history">
                <?php foreach ($orders as $order): ?>
                    <li>
                        Zamówienie nr <?php echo $order['id']; ?> - <?php echo number_format($order['total'], 2); ?> PLN - <?php echo $order['order_date']; ?>
                        <a href="zamowienie-szczegoly.php?order_id=<?php echo $order['id']; ?>">Szczegóły</a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</div>
<div class="section-box">
    <h3>Dodawanie opinii</h3>
    <a href="dodawanie-opinii.php">Dodaj opinię o produkcie</a>
</div>
<?php
include 'footer.php';
?>

