<?php
include 'header.php';
?>
<link rel="stylesheet" type="text/css" href="koszyk-styles.css">
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'add') {
        $id = intval($_POST['id']);
        $rozmiar = $_POST['rozmiar'];
        if (!isset($_SESSION['koszyk'])) {
            $_SESSION['koszyk'] = [];
        }

        $item = ['id' => $id, 'rozmiar' => $rozmiar];
        if (!in_array($item, $_SESSION['koszyk'])) {
            $_SESSION['koszyk'][] = $item;
        }
    } elseif (isset($_POST['action']) && $_POST['action'] === 'remove') {
        $id = intval($_POST['id']);
        $rozmiar = $_POST['rozmiar'];
        $item = ['id' => $id, 'rozmiar' => $rozmiar];
        if (($key = array_search($item, $_SESSION['koszyk'])) !== false) {
            unset($_SESSION['koszyk'][$key]);
        }
    } elseif (isset($_POST['action']) && $_POST['action'] === 'apply_discount') {
        $discount_code = $_POST['discount_code'];
        if ($discount_code === 'PROMO10') {
            $_SESSION['discount'] = 0.1; // 10% rabatu
        } else {
            $_SESSION['discount'] = 0; // brak rabatu
        }
    }

    header("Location: koszyk.php");
    exit();
}

$db = new mysqli("localhost", "my_user", "my_password", "wprg-projekt");

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$produkty = [];
$sum = 0;
if (isset($_SESSION['koszyk']) && count($_SESSION['koszyk']) > 0) {
    $ids = array_column($_SESSION['koszyk'], 'id');
    $ids_placeholders = implode(',', array_fill(0, count($ids), '?'));
    $types = str_repeat('i', count($ids));
    $stmt = $db->prepare("SELECT * FROM produkty WHERE id IN ($ids_placeholders)");
    $stmt->bind_param($types, ...$ids);
    $stmt->execute();
    $result = $stmt->get_result();
    $produkty_raw = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    foreach ($_SESSION['koszyk'] as $item) {
        foreach ($produkty_raw as $produkt) {
            if ($produkt['id'] == $item['id']) {
                $produkt['rozmiar'] = $item['rozmiar'];
                $produkty[] = $produkt;
                $sum += $produkt['cena'];
                break;
            }
        }
    }

    if (isset($_SESSION['discount'])) {
        $sum -= $sum * $_SESSION['discount'];
    }
}
$db->close();
?>
<div class="koszyk-container">
    <h2 class="koszyk-title">Twój Koszyk</h2>
    <div class="koszyk-list">
        <?php if (empty($produkty)): ?>
            <p class="koszyk-empty">Twój koszyk jest pusty.</p>
        <?php else: ?>
            <?php foreach ($produkty as $produkt): ?>
                <div class="koszyk-item">
                    <img src="<?php echo $produkt['obrazek']; ?>" alt="<?php echo $produkt['marka']; ?>">
                    <div class="koszyk-item-details">
                        <h3><?php echo $produkt['marka'] . " " . $produkt['model']; ?> (Rozmiar: <?php echo $produkt['rozmiar']; ?>)</h3>
                        <p class="koszyk-price"><?php echo $produkt['cena']; ?> PLN</p>
                        <form action="koszyk.php" method="post">
                            <input type="hidden" name="id" value="<?php echo $produkt['id']; ?>">
                            <input type="hidden" name="rozmiar" value="<?php echo $produkt['rozmiar']; ?>">
                            <input type="hidden" name="action" value="remove">
                            <button type="submit" class="koszyk-button">Usuń</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <?php if (!empty($produkty)): ?>
        <div class="koszyk-summary">
            <h3>Podsumowanie:</h3>
            <p>Łączna wartość: <?php echo number_format($sum, 2); ?> PLN</p>
            <form action="koszyk.php" method="post">
                <input type="hidden" name="action" value="apply_discount">
                <input type="text" name="discount_code" placeholder="Kod rabatowy">
                <button type="submit" class="koszyk-button">Zastosuj</button>
            </form>
        </div>
        <div class="koszyk-checkout">
            <form action="zamowienie-skladanie.php" method="get">
                <button type="submit" class="koszyk-button">Zamawiam</button>
            </form>
        </div>
    <?php endif; ?>
</div>
<?php
include 'footer.php';
?>
