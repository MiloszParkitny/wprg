<?php
include 'header.php';

$db = new mysqli("localhost", "my_user", "my_password", "wprg-projekt");

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$marka = isset($_GET['marka']) ? $_GET['marka'] : '';
$cena_min = isset($_GET['cena_min']) ? $_GET['cena_min'] : 0;
$cena_max = isset($_GET['cena_max']) ? $_GET['cena_max'] : 999999;

$query = "SELECT DISTINCT p.* FROM produkty p WHERE p.kategoria = 'Akcesoria'";

$params = [];
$types = '';

if ($marka) {
    $query .= " AND p.marka = ?";
    $params[] = $marka;
    $types .= 's';
}

$query .= " AND p.cena BETWEEN ? AND ?";
$params[] = $cena_min;
$params[] = $cena_max;
$types .= 'ii';

$stmt = $db->prepare($query);

if ($types) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$produkty = $result->fetch_all(MYSQLI_ASSOC);

$stmt->close();
$db->close();
?>
<h2 class="h2-moje-konto">Akcesoria</h2>
<div class="kategoria-content">
    <aside class="kategoria-filters">
        <form method="get" action="kategoria-akcesoria.php">
            <div class="kategoria-filter-group">
                <label for="kategoria-marka">Marka:</label>
                <select name="marka" id="kategoria-marka">
                    <option value="">Wszystkie</option>
                    <?php
                    $marki = ['DOLCE & GABBANA', 'NIKE', 'SUPREME', 'IKEA', 'BEARBRICK', ' BAPE', 'A Bathing Ape'];
                    foreach ($marki as $m) {
                        echo "<option value=\"$m\" " . ($marka == $m ? 'selected' : '') . ">$m</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="kategoria-filter-group">
                <label for="kategoria-cena_min">Cena od:</label>
                <input type="number" name="cena_min" id="kategoria-cena_min" value="<?php echo $cena_min; ?>">
            </div>
            <div class="kategoria-filter-group">
                <label for="kategoria-cena_max">Cena do:</label>
                <input type="number" name="cena_max" id="kategoria-cena_max" value="<?php echo $cena_max; ?>">
            </div>
            <button type="submit" class="kategoria-filter-button">Filtruj</button>
        </form>
    </aside>
    <div class="kategoria-product-list">
        <?php foreach ($produkty as $produkt): ?>
            <div class="kategoria-product-item">
                <a href="produkt.php?id=<?php echo $produkt['id']; ?>">
                    <img src="<?php echo $produkt['obrazek']; ?>" alt="<?php echo $produkt['model']; ?>">
                    <div class="kategoria-marka-model">
                        <h3><?php echo $produkt['marka'] . " " . $produkt['model']; ?></h3>
                    </div>
                    <p class="kategoria-price"><?php echo $produkt['cena']; ?> PLN</p>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php
include 'footer.php';
?>
