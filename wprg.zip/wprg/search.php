<?php
include 'header.php';
$db = new mysqli("localhost", "my_user", "my_password", "wprg-projekt");

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$query = isset($_GET['query']) ? '%' . $db->real_escape_string($_GET['query']) . '%' : '';

$q = $db->prepare("SELECT * FROM produkty WHERE marka LIKE ? OR opis LIKE ?");
$q->bind_param("ss", $query, $query);
$q->execute();
$result = $q->get_result();
$produkty = $result->fetch_all(MYSQLI_ASSOC);
$q->close();
$db->close();
?>
<h2 class="h2-moje-konto">Wyniki wyszukiwania</h2>
<div class="product-list">
    <?php if (empty($produkty)): ?>
        <p>Brak wyników dla zapytania.</p>
    <?php else: ?>
        <?php foreach ($produkty as $produkt): ?>
            <div class="product-item">
                <a href="produkt.php?id=<?php echo $produkt['id']; ?>">
                    <img src="<?php echo $produkt['obrazek']; ?>" alt="<?php echo $produkt['marka']; ?>">
                    <h3><?php echo $produkt['marka'] . " " . $produkt['model'];; ?></h3>
                    <p><?php echo $produkt['opis']; ?></p>
                    <p class="price"><?php echo $produkt['cena']; ?> PLN</p>
                </a>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
<?php
include 'footer.php';
?>
