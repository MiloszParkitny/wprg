<?php
include 'header.php';
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

$order_id = $_GET['id'];
$db = new mysqli("localhost", "my_user", "my_password", "wprg-projekt");

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$stmt = $db->prepare("SELECT * FROM zamowienia WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

$stmt = $db->prepare("SELECT p.marka, p.model, zp.rozmiar, p.cena FROM zamowienia_produkty zp JOIN produkty p ON zp.produkt_id = p.id WHERE zp.zamowienie_id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$db->close();
?>
<div class="details-container">
    <h2 class="details-title">Szczegóły Zamówienia</h2>
    <p class="details-item">ID Zamówienia: <?php echo $order['id']; ?></p>
    <p class="details-item">ID Użytkownika: <?php echo $order['user_id']; ?></p>
    <p class="details-item">Łączna Cena: <?php echo $order['total']; ?> PLN</p>
    <p class="details-item">Data Zamówienia: <?php echo $order['order_date']; ?></p>
    <h3 class="details-subtitle">Produkty</h3>
    <ul class="details-product-list">
        <?php foreach ($products as $product): ?>
            <li class="details-product-item"><?php echo $product['marka'] . " " . $product['model'] . " - Rozmiar: " . $product['rozmiar'] . " - Cena: " . $product['cena'] . " PLN"; ?></li>
        <?php endforeach; ?>
    </ul>
</div>
<?php include 'footer.php'; ?>

