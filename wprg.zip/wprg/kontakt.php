<?php
include 'header.php';
?>

<div class="kontakt-container">
    <h2 class="kontakt-title">Znajdź nas</h2>
    <iframe
        class="kontakt-map"
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d824.7205264599479!2d18.647292226435237!3d54.22147313476304!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46fd71fe22520ad7%3A0x2525a6d16bf22f7!2zxbthYmth!5e0!3m2!1spl!2spl!4v1719167520438!5m2!1spl!2spl"
        width="600"
        height="450"
        style="border:0;"
        allowfullscreen=""
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade">
    </iframe>
    <ul class="kontakt-hours">
        <li>Poniedziałek: 10.00-18.00</li>
        <li>Wtorek: 10.00-18.00</li>
        <li>Środa: 10.00-18.00</li>
        <li>Czwartek: 10.00-18.00</li>
        <li>Piątek: 10.00-18.00</li>
        <li>Sobota: 10.00-14.00</li>
        <li>Niedziela: Zamknięte</li>
    </ul>
    <h4 class="kontakt-phone-title">Numer telefonu</h4>
    <p class="kontakt-phone">Jeśli masz jakieś pytania, zadzwoń do nas pod numer: <a href="tel:+48123456789">+48 123 ### ###</a></p>
    <h4 class="kontakt-email-title">Email</h4>
    <p class="kontakt-email">Skontaktuj się z nami pod adresem: <a href="mailto:example.store@example.com">example.store@example.com</a></p>
</div>
<?php include 'footer.php'; ?>

