<?php
$db = new mysqli("localhost", "my_user", "my_password", "wprg-projekt");

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$kategorie = ['buty', 'ubrania', 'Akcesoria'];
$produkty_kategorie = [];

foreach ($kategorie as $kategoria) {
    $q = $db->prepare("SELECT * FROM produkty WHERE kategoria = ? LIMIT 6");
    $q->bind_param("s", $kategoria);
    $q->execute();
    $result = $q->get_result();
    $produkty_kategorie[$kategoria] = $result->fetch_all(MYSQLI_ASSOC);
    $q->close();
}

$db->close();

include 'header.php';
?>
<div class="kategoria">
<?php foreach ($produkty_kategorie as $kategoria => $produkty): ?>
    <div class="category-section">
        <h2><?php echo ucfirst($kategoria); ?> ></h2>
    </div>
    <div class="product-list">
        <?php foreach ($produkty as $produkt): ?>
            <div class="product-item">
                <a href="produkt.php?id=<?php echo $produkt['id']; ?>">
                    <img src="<?php echo $produkt['obrazek']; ?>" alt="<?php echo $produkt['model']; ?>">
                    <div class="marka-model">
                    <h3><?php echo $produkt['marka'] . " " . $produkt['model']; ?></h3>
                    <p class="price"><?php echo $produkt['cena']; ?> PLN</p>
                    </div>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
<?php endforeach; ?>
</div><br>


<?php
include 'footer.php';
?>

