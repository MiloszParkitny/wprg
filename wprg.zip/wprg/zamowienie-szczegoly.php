<?php
include 'header.php';
if (!isset($_GET['order_id'])) {
    header("Location: index.php");
    exit();
}

$order_id = $_GET['order_id'];

$db = new mysqli("localhost", "my_user", "my_password", "wprg-projekt");
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$stmt = $db->prepare("SELECT * FROM zamowienia WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $order_id, $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();
$stmt->close();

$stmt = $db->prepare("SELECT p.marka, p.model, p.obrazek, zp.rozmiar FROM zamowienia_produkty zp JOIN produkty p ON zp.produkt_id = p.id WHERE zp.zamowienie_id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();
$products = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$db->close();

if (!$order) {
    echo "Nie znaleziono zamówienia.";
    exit();
}
?>
    <div class="zamowienie-szczegoly-container">
        <h2>Szczegóły zamówienia</h2>
        <p><span class="zamowienie-szczegoly-label">Numer zamówienia:</span> <?php echo $order_id; ?></p>
        <p><span class="zamowienie-szczegoly-label">Łączna wartość:</span> <?php echo number_format($order['total'], 2); ?> PLN</p>
        <p><span class="zamowienie-szczegoly-label">Data zamówienia:</span> <?php echo $order['order_date']; ?></p>

        <h3>Adres wysyłki</h3>
        <p><span class="zamowienie-szczegoly-label">Imię i nazwisko:</span> <?php echo $order['shipping_name']; ?></p>
        <p><span class="zamowienie-szczegoly-label">Adres:</span> <?php echo $order['shipping_address']; ?></p>
        <p><span class="zamowienie-szczegoly-label">Miasto:</span> <?php echo $order['shipping_city']; ?></p>
        <p><span class="zamowienie-szczegoly-label">Kod pocztowy:</span> <?php echo $order['shipping_zip']; ?></p>
        <p><span class="zamowienie-szczegoly-label">Kraj:</span> <?php echo $order['shipping_country']; ?></p>

        <h3>Metoda płatności</h3>
        <p><span class="zamowienie-szczegoly-label">Metoda płatności:</span> <?php echo $order['payment_method']; ?></p>

        <h3>Kontakt</h3>
        <p><span class="zamowienie-szczegoly-label">Email:</span> <?php echo $order['contact_email']; ?></p>
        <p><span class="zamowienie-szczegoly-label">Telefon:</span> <?php echo $order['contact_phone']; ?></p>

        <h3>Produkty</h3>
        <ul class="zamowienie-szczegoly-product-list">
            <?php foreach ($products as $product): ?>
                <li class="zamowienie-szczegoly-product-item">
                    <img src="<?php echo $product['obrazek']; ?>" alt="<?php echo $product['model']; ?>">
                    <div class="zamowienie-szczegoly-product-details">
                        <?php echo $product['marka'] . " " . $product['model'] . " (Rozmiar: " . $product['rozmiar'] . ")"; ?>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>


<?php
include "footer.php";
