<?php
include 'header.php';
?>
<?php
$db = new mysqli("localhost", "my_user", "my_password", "wprg-projekt");

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$q = $db->prepare("SELECT * FROM produkty WHERE id = ?");
$q->bind_param("i", $id);
$q->execute();
$result = $q->get_result();
$produkt = $result->fetch_assoc();
$q->close();

$q = $db->prepare("SELECT rozmiar FROM produkty_rozmiary WHERE produkt_id = ?");
$q->bind_param("i", $id);
$q->execute();
$result = $q->get_result();
$rozmiary = $result->fetch_all(MYSQLI_ASSOC);
$q->close();
$q = $db->prepare("SELECT ocena, komentarz FROM opinie WHERE produkt_id = ?");
$q->bind_param("i", $id);
$q->execute();
$result = $q->get_result();
$opinie = $result->fetch_all(MYSQLI_ASSOC);
$q->close();

$sumaOcen = 0;
$liczbaOcen = count($opinie);

foreach ($opinie as $opinia) {
    $sumaOcen += $opinia['ocena'];
}

$sredniaOcen = $liczbaOcen > 0 ? $sumaOcen / $liczbaOcen : 0;

$db->close();

if (!$produkt) {
    echo "Produkt nie został znaleziony!";
    exit();
}
?>
<div class="produkt-detail-container">
    <div class="produkt-detail">
        <img src="<?php echo htmlspecialchars($produkt['obrazek']); ?>" alt="<?php echo htmlspecialchars($produkt['marka']); ?>">
        <div class="produkt-info">
            <h1><?php echo htmlspecialchars($produkt['marka']) . " " . htmlspecialchars($produkt['model']); ?></h1>
            <p><?php echo htmlspecialchars($produkt['opis']); ?></p>
            <p class="produkt-price"><?php echo htmlspecialchars($produkt['cena']); ?> PLN</p>
            <form action="koszyk.php" method="post">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="id" value="<?php echo $produkt['id']; ?>">
                <label for="produkt-rozmiar">Wybierz rozmiar:</label>
                <select name="rozmiar" id="produkt-rozmiar" required>
                    <?php foreach ($rozmiary as $rozmiar): ?>
                        <option value="<?php echo htmlspecialchars($rozmiar['rozmiar']); ?>"><?php echo htmlspecialchars($rozmiar['rozmiar']); ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="produkt-button">Dodaj do koszyka</button>
            </form>
        </div>
    </div>
    <div class="opinie-reviews">
        <h2>Opinie o produkcie</h2>
        <?php if ($liczbaOcen > 0): ?>
            <p class="opinie-srednia">Średnia ocena: <?php echo number_format($sredniaOcen, 2); ?>/5</p>
            <?php foreach ($opinie as $opinia): ?>
            <div class="opinie-review">
                <p><strong>Ocena:</strong> <?php echo htmlspecialchars($opinia['ocena']); ?>/5</p>
                <p><?php echo nl2br(htmlspecialchars($opinia['komentarz'])); ?></p>
            </div>
            <?php endforeach; ?>
    <?php else: ?>
            <p>Brak opinii o tym produkcie.</p>
        <?php endif; ?>
    </div>
</div>
<?php
include 'footer.php';
?>
