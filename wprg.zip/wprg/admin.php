<?php
include 'header.php';
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: index.php");
    exit();
}
$db = new mysqli("localhost", "my_user", "my_password", "wprg-projekt");

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
$section = isset($_GET['section']) ? $_GET['section'] : 'orders';

switch ($section) {
    case 'orders':
        $query = "SELECT * FROM zamowienia";
        $result = $db->query($query);
        $orders = $result->fetch_all(MYSQLI_ASSOC);
        break;
    case 'products':
        $query = "SELECT * FROM produkty";
        $result = $db->query($query);
        $products = $result->fetch_all(MYSQLI_ASSOC);
        break;
    case 'users':
        $query = "SELECT * FROM user";
        $result = $db->query($query);
        $users = $result->fetch_all(MYSQLI_ASSOC);
        break;
}

$db->close();
?>
<h2 class="h2-moje-konto">Panel Administratora</h2>
<nav class="admin-nav">
    <ul>
        <li><a href="admin.php?section=orders">Zamówienia</a></li>
        <li><a href="admin.php?section=products">Produkty</a></li>
        <li><a href="admin.php?section=users">Użytkownicy</a></li>
    </ul>
</nav>

<div class="admin-content">
    <?php if ($section == 'orders'): ?>
        <h3 class="admin-subtitle">Zamówienia</h3>
        <table class="admin-table">
            <thead>
            <tr>
                <th>ID</th>
                <th>Użytkownik</th>
                <th>Łączna cena</th>
                <th>Data zamówienia</th>
                <th>Akcje</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($orders as $order): ?>
                <tr>
                    <td><?php echo $order['id']; ?></td>
                    <td><?php echo $order['user_id']; ?></td>
                    <td><?php echo $order['total']; ?> PLN</td>
                    <td><?php echo $order['order_date']; ?></td>
                    <td>
                        <a href="order-details.php?id=<?php echo $order['id']; ?>">Szczegóły</a>
                        <a href="delete-order.php?id=<?php echo $order['id']; ?>">Usuń</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php elseif ($section == 'products'): ?>
        <h3 class="admin-subtitle">Produkty</h3>
        <a href="add-product.php" class="admin-add-button">Dodaj Nowy Produkt</a>
        <table class="admin-table">
            <thead>
            <tr>
                <th>ID</th>
                <th>Marka</th>
                <th>Model</th>
                <th>Cena</th>
                <th>Kategoria</th>
                <th>Akcje</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($products as $product): ?>
                <tr>
                    <td><?php echo $product['id']; ?></td>
                    <td><?php echo $product['marka']; ?></td>
                    <td><?php echo $product['model']; ?></td>
                    <td><?php echo $product['cena']; ?> PLN</td>
                    <td><?php echo $product['kategoria']; ?></td>
                    <td>
                        <a href="edit-product.php?id=<?php echo $product['id']; ?>">Edytuj</a>
                        <a href="delete-product.php?id=<?php echo $product['id']; ?>">Usuń</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php elseif ($section == 'users'): ?>
        <h3 class="admin-subtitle">Użytkownicy</h3>
        <table class="admin-table">
            <thead>
            <tr>
                <th>ID</th>
                <th>Imię</th>
                <th>Nazwisko</th>
                <th>Email</th>
                <th>Akcje</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo $user['id']; ?></td>
                    <td><?php echo $user['imie']; ?></td>
                    <td><?php echo $user['nazwisko']; ?></td>
                    <td><?php echo $user['email']; ?></td>
                    <td>
                        <a href="delete-user.php?id=<?php echo $user['id']; ?>">Usuń</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php
include 'footer.php';
?>



