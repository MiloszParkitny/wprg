</main>
<footer>
    <div class="small-footer">
        <div class="footer-info">
            <a href="#">O nas</a>
            <a href="kontakt.php">Kontakt</a>
            <a href="#">Regulamin</a>
        </div>
        <div class="social-media">
            <a href="https://www.instagram.com/"><img src="icon/icon-instagram.png" alt="Instagram"></a>
            <a href="https://www.facebook.com/"><img src="icon/icon-facebook.png" alt="Facebook"></a>
            <a href="https://x.com/x"><img src="icon/icon-x.png" alt="X"></a>
        </div>
        <div class="newsletter">
            <input type="email" placeholder="Wpisz swój e-mail">
            <button>Zapisz się</button>
        </div>
    </div>
</footer>
</body>
</html>

