<?php
include 'header.php';
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = new mysqli("localhost", "my_user", "my_password", "wprg-projekt");

    if ($db->connect_error) {
        die("Connection failed: " . $db->connect_error);
    }

    $marka = $_POST['marka'];
    $model = $_POST['model'];
    $opis = $_POST['opis'];
    $cena = $_POST['cena'];
    $kategoria = $_POST['kategoria'];
    $obrazek = $_POST['obrazek'];

    $stmt = $db->prepare("INSERT INTO produkty (marka, model, opis, cena, kategoria, obrazek) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssdss", $marka, $model, $opis, $cena, $kategoria, $obrazek);
    $stmt->execute();
    $stmt->close();
    $db->close();

    header("Location: admin.php?section=products");
    exit();
}
?>
    <h2 class="h2-moje-konto">Dodaj Nowy Produkt</h2>
<form action="add-product.php" method="post" class="dodaj-form">
    <label for="marka" class="dodaj-label">Marka:</label>
    <input type="text" id="marka" name="marka" required class="dodaj-input">

    <label for="model" class="dodaj-label">Model:</label>
    <input type="text" id="model" name="model" required class="dodaj-input">

    <label for="opis" class="dodaj-label">Opis:</label>
    <textarea id="opis" name="opis" required class="dodaj-textarea"></textarea>

    <label for="cena" class="dodaj-label">Cena:</label>
    <input type="number" id="cena" name="cena" step="0.01" required class="dodaj-input">

    <label for="kategoria" class="dodaj-label">Kategoria:</label>
    <input type="text" id="kategoria" name="kategoria" required class="dodaj-input">

    <label for="obrazek" class="dodaj-label">Obrazek:</label>
    <input type="text" id="obrazek" name="obrazek" required class="dodaj-input">

    <button type="submit" class="dodaj-button">Dodaj Produkt</button>
</form>
<?php include 'footer.php'; ?>


