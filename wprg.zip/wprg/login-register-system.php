<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = new mysqli("localhost", "my_user", "my_password", "wprg-projekt");

    if ($db->connect_error) {
        die("Connection failed: " . $db->connect_error);
    }

    if ($_REQUEST['action'] == "login") {
        $email = filter_var($_REQUEST['email'], FILTER_SANITIZE_EMAIL);
        $password = $_REQUEST['password'];

        if ($email === 'admin@admin.pl' && $password === 'admin') {
            $_SESSION['user_id'] = 1; // ID administratora, zakładając, że jest to ID 1 w bazie danych
            $_SESSION['user_email'] = $email;
            $_SESSION['user_role'] = 'admin';
            header("Location: admin.php");
            exit();
        }

        $q = $db->prepare("SELECT * FROM user WHERE email = ? LIMIT 1");
        $q->bind_param("s", $email);
        $q->execute();
        $result = $q->get_result();
        $userRow = $result->fetch_assoc();
        $q->close();

        if ($userRow && password_verify($password, $userRow['haslo'])) {
            $_SESSION['user_id'] = $userRow['id'];
            $_SESSION['user_email'] = $userRow['email'];
            $_SESSION['user_role'] = 'user';
            header("Location: index.php");
            exit();
        } else {
            $_SESSION['error_message'] = "Błędny login lub hasło";
            header("Location: login-register.php");
            exit();
        }
    } elseif ($_REQUEST['action'] == "register") {
        $firstname = $_REQUEST['firstname'];
        $lastname = $_REQUEST['lastname'];
        $email = filter_var($_REQUEST['email'], FILTER_SANITIZE_EMAIL);
        $password = $_REQUEST['password'];
        $passwordRepeat = $_REQUEST['passwordRepeat'];

        if ($password !== $passwordRepeat) {
            $_SESSION['error_message'] = "Hasła nie są zgodne - spróbuj ponownie!";
            $db->close();
            header("Location: login-register.php");
            exit();
        }

        $q = $db->prepare("SELECT email FROM user WHERE email = ? LIMIT 1");
        $q->bind_param("s", $email);
        $q->execute();
        $q->store_result();

        if ($q->num_rows > 0) {
            $_SESSION['error_message'] = "Konto z tym adresem email już istnieje!";
            $q->close();
            $db->close();
            header("Location: login-register.php");
            exit();
        }
        $q->close();

        $passwordHash = password_hash($password, PASSWORD_ARGON2I);
        $q = $db->prepare("INSERT INTO user (imie, nazwisko, email, haslo) VALUES (?, ?, ?, ?)");
        $q->bind_param("ssss", $firstname, $lastname, $email, $passwordHash);

        if ($q->execute()) {
            $_SESSION['register_success'] = "Konto utworzono poprawnie. Możesz teraz się zalogować.";
        } else {
            $_SESSION['error_message'] = "Coś poszło nie tak!";
        }

        $q->close();
        header("Location: login-register.php");
        exit();
    } elseif ($_REQUEST['action'] == "logout") {
        session_destroy();
        header("Location: login-register.php");
        exit();
    }

    $db->close();
}
?>
