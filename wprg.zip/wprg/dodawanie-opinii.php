<?php
include 'header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login-register.php");
    exit();
}

$servername = "localhost";
$username = "my_user";
$password = "my_password";
$dbname = "wprg-projekt";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
    $produkt_id = $_POST['produkt_id'];
    $user_id = $_SESSION['user_id'];
    $ocena = $_POST['ocena'];
    $komentarz = $_POST['komentarz'];

    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $conn->prepare("INSERT INTO opinie (produkt_id, uzytkownik_id, ocena, komentarz) VALUES (:produkt_id, :uzytkownik_id, :ocena, :komentarz)");
    $stmt->bindParam(':produkt_id', $produkt_id);
    $stmt->bindParam(':uzytkownik_id', $user_id);
    $stmt->bindParam(':ocena', $ocena);
    $stmt->bindParam(':komentarz', $komentarz);

    $stmt->execute();

    $_SESSION['success_message'] = "Opinia została dodana pomyślnie!";
    header("Location: moje-konto.php");
    exit();
}

$produkty = [];
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stmt = $conn->query("SELECT id, marka, model FROM produkty");
$produkty = $stmt->fetchAll(PDO::FETCH_ASSOC);
$conn = null;
?>
<h2>Dodaj opinię o produkcie</h2>
<form action="dodawanie-opinii.php" method="post" class="dodawanie-form">
    <label for="produkt_id">Produkt:</label>
    <select id="produkt_id" name="produkt_id" required>
        <?php
        foreach ($produkty as $produkt) {
            echo "<option value='" . htmlspecialchars($produkt['id']) . "'>" . htmlspecialchars($produkt['marka']) . " " . htmlspecialchars($produkt['model']) . "</option>";
        }
        ?>
    </select>

    <label for="ocena">Ocena:</label>
    <select name="ocena" id="ocena" required>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
    </select>

    <label for="komentarz">Komentarz:</label>
    <textarea name="komentarz" id="komentarz" required></textarea>

    <button type="submit" name="submit_review">Dodaj opinię</button>
</form>
<a href="moje-konto.php">Wróć do Mojego Konta</a>
<?php
include 'footer.php';
?>
