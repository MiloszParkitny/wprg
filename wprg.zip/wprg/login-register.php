<?php
include 'header.php';
if (isset($_SESSION['error_message'])) {
    echo "<div class='error'>" . $_SESSION['error_message'] . "</div>";
    unset($_SESSION['error_message']);
}

if (isset($_SESSION['success_message'])) {
    echo "<div class='success'>" . $_SESSION['success_message'] . "</div>";
    unset($_SESSION['success_message']);
}

if (isset($_SESSION['user_id'])) {
    echo "<p>Witaj, jesteś zalogowany jako " . $_SESSION['user_email'] . "</p>";
} else {
    ?>
    <div class="login-form">
        <h2>Logowanie</h2>
        <form action="login-register-system.php" method="post">
            <input type="hidden" name="action" value="login">
            <label for="email">Adres Email:</label>
            <input type="email" id="email" name="email" required>
            <label for="password">Hasło:</label>
            <input type="password" id="password" name="password" required>
            <button type="submit">Zaloguj się</button>
        </form>
    </div>
    <div class="register-form">
        <h2>Rejestracja</h2>
        <?php
        if (isset($_SESSION['register_success'])) {
            echo "<div class='success'>" . $_SESSION['register_success'] . "</div>";
            unset($_SESSION['register_success']);
        }
        ?>
        <form action="login-register-system.php" method="post">
            <input type="hidden" name="action" value="register">
            <label for="firstname">Imię:</label>
            <input type="text" id="firstname" name="firstname" required>
            <label for="lastname">Nazwisko:</label>
            <input type="text" id="lastname" name="lastname" required>
            <label for="email-register">Adres Email:</label>
            <input type="email" id="email-register" name="email" required>
            <label for="password-register">Hasło:</label>
            <input type="password" id="password-register" name="password" required>
            <label for="confirm-password">Powtórz Hasło:</label>
            <input type="password" id="confirm-password" name="passwordRepeat" required>
            <button type="submit">Zarejestruj się</button>
        </form>
    </div>
    <?php
}
include 'footer.php';
?>

